Li Ju
########
property-based testing functions for each problem: 
[Stack permutations]:
 - prop_unsortable()
 - prop_efficiency()

[Graph Coloring]: 
A). graph data structure implementation:
 - prop_pairwise_adj()
 - prop_edge_verts()
B). kcolor algorithm implementation: 
 - prop_color_length()
 - prop_adj_color()

[Vector Calculator Server]: 
Testings are done for this probblem as well. Because it is not mentioned that
property based testing should be explicitly done and will be graded, I commented 
testing part. 
