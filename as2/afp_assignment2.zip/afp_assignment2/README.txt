Li Ju
########
property-based testing functions for each problem: 
[Stack permutations]:
 - prop_unsortable()
 - prop_self()
 - prop_eff()

[Graph Coloring]: 
A). graph data structure implementation:
 - prop_pairwiseAdj()
 - prop_edgeVert()
B). kcolor algorithm implementation: 
 - prop_colorLength()
 - prop_adjColor()
